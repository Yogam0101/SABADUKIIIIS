package com.example.concesionario_sabado;

public class REGISTROCLIENTES {
    private String identificacion;
    private String nombre;
    private String dirección;
    private String telefono;
    private String Activo;

    public REGISTROCLIENTES(String identificacion, String nombre, String dirección, String telefono, String activo) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.dirección = dirección;
        this.telefono = telefono;
        Activo = activo;
    }

    @Override
    public String toString() {
        return "REGISTROCLIENTES{" +
                "identificacion='" + identificacion + '\'' +
                ", nombre='" + nombre + '\'' +
                ", dirección='" + dirección + '\'' +
                ", telefono='" + telefono + '\'' +
                ", Activo='" + Activo + '\'' +
                '}';
    }
}

