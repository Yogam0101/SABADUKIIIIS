package com.example.concesionario_sabado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class LISTARCLIENTESACTIVITY extends AppCompatActivity {

    ArrayList<CLsLISTARCLIENTESACTIVITY> alclientes=new ArrayList<CLsLISTARCLIENTESACTIVITY<>();
    )

    ArrayAdapter<ClsREGISTROCLIENTES> aaclientes;
    ClsOpenHelper admin=new ClsOpenHelper ( context:this,name: "CONCESIONARIO_SABADO,db");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listarclientesactivity);
        //ocultar la barra de titulo por defecto
        getSupportActionBar() .hide();
        //Asociar objetos java con objetos xml
        lvCLIENTES= findViewById(R.id lvCLIENTES);
        //ABRIR LA CONEXIÓN EN MODO LECTURA
        SQLiteDatabase db=admin.getReadableDatabase();
        Cursor registro=db.rawQuery(Sql:"select * from TblCLIENTES", selectionArgs:null)
        //MOVER LA INFORMACION DEL CURSOR A UN ARRAYLIST
        for(int k=0;k<registro.getCount ();k++){
            registro.moveToNext();
            ClsRegistroClientes objeregistro=new
                    ClsRegistroClientes(registro.getString (columnIndex:0))
                    ClsRegistroClientes(registro.getString(columnIndex:1),registro.getString (ColumnIndex:2),
            alclientes.add(objeregistro);

        }
                    //LLEVAR AL ADAPTADOR EL ARRAYLIST
            aaclientes=new ArrayAdapter<>( context:this,android.R.layout.simple_list_item_1,alclientes)
//DESCARGUE LOS DATOS ADAPTADOS EN EL LISTVIEW
            lvCLIENTES.setAdapter(aaclientes);
        db.close();
    } //FIN MÉTODO ONCREATE
    public void REGRESAR (View view) {
        Intent intCLIENTES=new Intent(packageContext:this,ClientesActivity.class)
        startActivity(intCLIENTES);
    }

}