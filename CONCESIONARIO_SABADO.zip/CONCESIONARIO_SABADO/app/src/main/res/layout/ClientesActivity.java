package com.example.concesionario_sabado;
import android.app.compat.app.AppCompatActivity
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android
import android
import android

boolean sw;
Toast.makeText (context:this, text: "Difgite identificación y luego click al botón")
        }
        //FIN MÉTODO onCreate
Public void CONSULTAR (view) {
    identificacion =jetIdentificacion.getText () . toString ();
        String identificacion, nombre,directorio,telefono
        if (!nombre.isEmpty ()&&!direccion.isEmpty()&&!telefono.isEmpty())
        SQLiteDatabase db=admin.getWriteDatabase();

        fila.put (="IDENTIFICACIONCLIENTES";IDENTIFICACION)
        fila.put("NOMBRECLIENTES"; Nombre);
        fila.put("DIRECCIÓN", direccion);
        fila.put ("TELEFONO",telefono);
        //LLENÉ ESE CONTENEDOR, guardar el registro en la base de datos

        if (sw == false)
            respuesta=db.insert (table:"TblCliente"),nullColumnHack:null,fila);
        respuest=db.insert (table:"TblClientes",nullColumnHack:null,fila);
        else {
        sw=false;
        respuesta=db.update (table:"TblClientes",fila,whereClause: "IDENTIFICACION_CLIENTES="+IDENTIFICACION+"",whereArgs:null);
        }
        if (respuesta>0){
        Toast.makeText(context:this,text:"REGISTRO GUARDADO",Toast.LENGTH:SHORT).show()
        db.close()

        }else
            Toast.makeText(context:this,text:"ERROR GUARDANDO REGISTRO")

        db.close();

    if (!identificación.isEmpty ()){
        SQLiteDatabase db=admin.getReadableDatabase ();
        Cursor registro=db.rawQuery ("Select * from TblCliente where Ident_Cliente=´"+Identificacion+"´", selectionArgs:null);

        if (registro.moveToNext()){
        } else{
            jcbactivo.setChecked(true);
            Toast.makeText(context:this, text: "CLIENTE REGISTRADO",Toast.LENGHT_SHORT).show ();
        jetnombre.setEnabled (true);
        jetdireccion.setEnabled(true);
        jetnombre.requestFocus();
        jbtguardar.setEnabled (true);
        jetidentificacion.setEnabled (false);
        db.close();
    } else{
        Toast.makeText(context: this, text:"LA IDENTIFICACIÓN ES REQUERIDA",Toast.LENGTH_SHORT).show( );
        jet.identificacion.requestFocus ();
        jetnombre.setEnabled (true);
        jetdireccion.setEnabled(true);
        jetnombre.requestFocus();
        jbtguardar.setEnabled (true);
        jetidentificacion.setEnabled (false);
        db.close ();
        }
        }

        //FIN MÉTODO CONSULTAR
public void GUARDAR (View view){
        Identificacion=jetidentificacion.getTedxt().toString();
        nombre=jetnombre.getText().toString();
        direccion=jetdireccion.getText().toString();
        telefono=jettelefono.getText().toString();
        //VALIDAR QUE A INFORMACIÓN ESTÉ COMPLETA)
        if(!nombre.isEmpty())&&!direccion.isEmpty()&&!telefono.isEmpty()){
        } else{
    Toast.makeText (context: this, text: "TODOS LOS CAMPOS SE TIENEN QUE LLENAR", Toast.LENGHT_SHORT).show ();

public void CANCELAR ()
    jetidentificacion.setText ("");
    jettelefono.setText("");
    jetnombre.setText ("");
    jetidentificacion.requesFocus();
    jetidentificacion.setEnabled (true);
    jetnombre.setEnabled(false);
    jettelefono.setEnabled(false);
    jetdireccion.setEnabled(false);
    jbtguardar.setEnabled (false);
    jbtanular.setEnabled(false);
    jcbtactivo.setChecked(false);
        } //fin método Cancelar
public void  LIMPIAR (View view)
        {
            cancelar ();
        }
        //FIN MÉTODO LIMPIAR
public void REGRESAR (View view){
    Intetn intmain=new Intent (packcageContext:this,ActivityMain.class);
    startActivity(intmain);
        }
        public void ANULAR (View view) {
        SQLiteDatabase db=admin.getWriteDatabase ();
        ContentValues fila=new ContentValues();
        if (jcbACTIVO.isChecked())
        fila.put ("ACTIVO", "NO";)
        else
                fila.put ("ACTIVO","SI");

respuesta=db.update(table:"TblCliente",fila,WhereClause:"´IDENTIFICACION_CLIENTES´"+IDENTIFICACION+"´,whereArgs:null);
        if (respuesta>0){
        Toast.makeText(content:this,text:"¡REGISTRO ANULADO!",Toast.LENGHT_SHORT);
        cancelar();
        }else{
                sw=false;
                Toast.makeText(context:this,text:"¡ERROR, ANULADO!"),Toast.LENGHT_SHORT);

        }
//FIN MÉTODO ANULAR
}
        }
        //FIN REGRESAR